package com.app.pojos;

public enum ProjectStatus {
	LAUNCHED, COMPLETED, CANCELLED
}
