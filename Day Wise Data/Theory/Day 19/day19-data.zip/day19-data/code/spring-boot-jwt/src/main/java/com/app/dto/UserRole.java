package com.app.dto;

public enum UserRole {
	ROLE_USER, ROLE_ADMIN,ROLE_CUSTOMER	
}
