package pojos;

public enum EmpType {
FULL_TIME,PART_TIME,CONTRACT
}
